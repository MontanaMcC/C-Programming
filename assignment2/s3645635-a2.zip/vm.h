/******************************************************************************
** Student name:    Montana McCallum
** Student number: 	s3645635
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#ifndef VM_H
#define VM_H

#include "vm_menu.h"

#endif

void deprecatedMenu(char * menu);
