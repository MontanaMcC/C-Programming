Name: Montana McCallum
Student No.: s3645635
Email: s3645635@student.rmit.edu.au

Couldn't validate some initialisation input. (placing player not on a blocked square).
Is a bit spaghetti code.